# Plataforma de CrowdFouding (Impulso)

Esse foi um site desenvolvido para com o objetivo de cumprir os requisitos da disciplina Programação Web, e praticar os ensinamentos quanto a HTML, CSS e JavaScript

As páginas compoem os elementos necessários para a publicação e apresentação de campanhas, como também por fim, o investimento.

A página <strong>Index.html</strong> possui: 
<ul>
  <li>Informações a plataforma;</li>
  <li>Prévia de campanhas;</li>
  <li>Localização do escritório.</li>
  <li></li>
</ul>

A página de <strong>Campanhas</strong> possui:
<ul>
  <li>Todas as campanhas cadastradas;</li>
  <li>Valor a faltar das campanhas.</li>
</ul>

A página de <strong>Cadastro</strong> possui:
<ul>
  <li>Todas opção para cadastrar nova startup ou investidor;</li>
</ul>


A página de <strong>Chat</strong> possui:
<ul>
  <li>Chatbot para recebimento de todo tipo de informação</li>
</ul>